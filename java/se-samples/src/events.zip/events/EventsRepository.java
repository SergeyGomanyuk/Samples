/**
 * Copyright (c) Amdocs jNetX.
 * http://www.amdocs.com
 * All rights reserved.
 * This software is the confidential and proprietary information of
 * Amdocs. You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license
 * agreement you entered into with Amdocs.
 * <p>
 * :$
 */
package events;

import java.util.function.Function;

/**
 * @author <a href="mailto:sergeygo@amdocs.com">Sergey Gomanyuk</a>
 * @version :$
 */
class EventsRepository {
    public Events updateEventsAtomically(Function<Events, Events> mapper) {
        return mapper.apply(new Events());
    }
}
