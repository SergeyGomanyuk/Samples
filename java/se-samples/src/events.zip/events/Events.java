/**
 * Copyright (c) Amdocs jNetX.
 * http://www.amdocs.com
 * All rights reserved.
 * This software is the confidential and proprietary information of
 * Amdocs. You shall not disclose such Confidential Information and
 * shall use it only in accordance with the terms of the license
 * agreement you entered into with Amdocs.
 * <p>
 * :$
 */
package events;

/**
 * @author <a href="mailto:sergeygo@amdocs.com">Sergey Gomanyuk</a>
 * @version :$
 */
// Эвент может находиться в состояниях:
//    - processing
//    - completed
//    - failed
// дополнительно:
//    - committed
//    - cancelled
class Events {

    public boolean isNew(String id) {
        return false;
    }

    // processing
    public void moveToProcessing(String id) {

    }

    public boolean isProcessing(String id) {
        return false;
    }

    // completed
    public boolean isCompleted(String id) {
        return false;
    }

    public void moveToCompleted(String id) {

    }

    // failed
    public boolean isFailed(String id) {
        return false;
    }


    public void moveToFailed(String id) {

    }

    // committed
    public boolean isComitted(String id) {
        return false;
    }

    public void moveToComitted(String id) {

    }

    // cancelled
    public boolean isCancelled(String id) {
        return false;
    }

    public void moveToCancelled(String id) {

    }
}
